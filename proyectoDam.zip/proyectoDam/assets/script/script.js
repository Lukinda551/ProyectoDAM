// function menu1(){
//     document.querySelector(".menu").style.display= "block";
//     document.querySelector(".menu1").style.display= "block";
// }
function menu1() {
    let checkboxMenu = document.querySelector("#menu-toggle");
    let checkboxCategoria = document.querySelector("#subcategorias-toggle");
    checkboxMenu.addEventListener("change", function () {
        if (!checkboxMenu.checked) {
            checkboxCategoria.checked = false;
        }
    });
}
function flog(){
    document.querySelector("header").style.display = "none";
    document.querySelector("footer").style.display = "none";
    document.querySelector("#div_modal").style.display = "flex";
    document.querySelector(".fondo").style.filter = "blur(10px)";
    document.querySelector(".fondo").style.opacity = "1";
    let botones = `<input type="button" value="Iniciar sesion" onclick="fCerrarModal()">`;
    botones+= `<input type="button" value="Cancelar" onclick="fCerrarModal()">`;
    document.querySelector(".botonera").innerHTML = botones;


}
function fsign(){
    document.querySelector("header").style.display = "none";
    document.querySelector("footer").style.display = "none";
    document.querySelector("#div_modal").style.display = "flex";
    document.querySelector(".fondo").style.filter = "blur(10px)";
    document.querySelector(".fondo").style.opacity = "1";
    document.querySelector(".nuevoregistro").style.display = "block";
    let botones = `<input type="button" value="Registrarse" onclick="fCerrarModal()">`;
    botones+= `<input type="button" value="Cancelar" onclick="fCerrarModal()">`;
    document.querySelector(".botonera").innerHTML = botones;

}
function fCerrarModal(){
    document.querySelector("#div_modal").style.display = "none";
    document.querySelector("header").style.display = "flex";
    document.querySelector("footer").style.display = "block";
    document.querySelector(".fondo").style.opacity = "0.5";
    document.querySelector(".fondo").style.filter = "none";
}